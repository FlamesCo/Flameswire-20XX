# Import the GitPython library
import git

# Define the repository path
repo_path = '/path/to/repo'

# Initialize the repository
repo = git.Repo(repo_path)

# Commit the changes
repo.index.commit('Add auto-gpt.js')

# Push the changes to the remote repository
origin = repo.remote(name='origin')
origin.push()