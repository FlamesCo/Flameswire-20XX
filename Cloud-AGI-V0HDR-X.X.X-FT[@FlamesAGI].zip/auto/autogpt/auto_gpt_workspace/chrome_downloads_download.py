# Import the Chrome browser API
import chrome

# Define the download options
options = {
    'url': 'https://example.com/auto-gpt.js',
    'filename': 'auto-gpt.js',
    'saveAs': False
}

# Download the file
chrome.downloads.download(options)