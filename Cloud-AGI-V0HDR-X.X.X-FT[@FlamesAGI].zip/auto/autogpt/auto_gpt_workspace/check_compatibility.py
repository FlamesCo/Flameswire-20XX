#!/usr/bin/env python

import platform

if platform.machine() == 'arm64':
    print('System is compatible with Mac OS M1')
else:
    print('System is not compatible with Mac OS M1')