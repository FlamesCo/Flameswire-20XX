import os
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By


chrome_options = Options()
chrome_options.add_argument('--headless')
chrome_options.add_argument('--disable-gpu')

chromedriver_path = os.path.join(os.getcwd(), 'chromedriver')


def scrape_api_documentation():
    with webdriver.Chrome(executable_path=chromedriver_path, options=chrome_options) as driver:
        url = 'https://developer.chrome.com/docs/extensions/mv3/downloads/'
        driver.get(url)
        wait = WebDriverWait(driver, 10)
        wait.until(EC.presence_of_element_located((By.XPATH, "//h1[text()='chrome.downloads']")))
        print(driver.current_url)


if __name__ == '__main__':
    scrape_api_documentation()