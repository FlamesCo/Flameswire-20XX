This document now lives at https://github.com/Significant-Gravitas/Auto-GPT/wiki/Contributing
